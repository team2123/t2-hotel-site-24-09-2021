import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomepageComponent } from './components/homepage/homepage.component';
import { RegisterComponent } from './components/register/register.component';
import { LoginComponent } from './components/login/login.component';
import { OrdersComponent } from './components/orders/orders.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { LogoutComponent } from './components/logout/logout.component';
import { AdminLoginComponent } from './components/admin/admin-login/admin-login.component';
import { UserListComponent } from './components/admin/user-list/user-list.component';
import { UserEditComponent } from './components/admin/user-edit/user-edit.component';
import { ItemAddComponent } from './components/admin/item-add/item-add.component';
import { ItemEditComponent } from './components/admin/item-edit/item-edit.component';
import { ItemListComponent } from './components/admin/item-list/item-list.component';
import { AdminDashboardComponent } from './components/admin/admin-dashboard/admin-dashboard.component';
//import { UserComponent } from './components/user/user.component';
import { OrderAddressComponent } from './components/order-address/order-address.component';
import { OrderSuccessfulComponent } from './components/order-successful/order-successful.component';
import { OrderCancelComponent } from './components/order-cancel/order-cancel.component';
import { UserEdit2Component } from './components/user-edit2/user-edit2.component';
import { CartComponent } from './components/cart/cart.component';
import { OrderListComponent } from './components/admin/order-list/order-list.component';
import { OrderEditComponent } from './components/admin/order-edit/order-edit.component';
import { OrderEdit2Component } from './components/order-edit2/order-edit2.component';
import { MyordersComponent } from './components/myorders/myorders.component';

const routes: Routes = [
  {path:'', component: HomepageComponent},
  {path:'register', component:RegisterComponent},
  {path:'login', component:LoginComponent},
  {path:'order', component: OrdersComponent},
  {path:'dashboard', component:  DashboardComponent},
  {path:'logout', component:  LogoutComponent},
  {path:'admin', component:  AdminLoginComponent},
  {path:'user-list', component:  UserListComponent},
  {path:'user-edit/:_id', component:  UserEditComponent, pathMatch:'full'},
  {path:'item-add', component:  ItemAddComponent},
  {path:'item-edit/:_id', component:  ItemEditComponent,pathMatch:'full'},
  {path:'item-list', component: ItemListComponent},
  {path:'admin-dashboard', component: AdminDashboardComponent},
  {path:'order-address',component:OrderAddressComponent},
  {path:'order-success',component:OrderSuccessfulComponent},
  {path:'order-cancel',component:OrderCancelComponent},
  {path:'user-edit2/:_id',component: UserEdit2Component, pathMatch:'full'},
  {path:'cart',component: CartComponent},
  {path:'order-list',component: OrderListComponent},
  {path:'order-edit/:_id',component: OrderEditComponent, pathMatch:'full'},
  {path:'order-edit2/:_id',component: OrderEdit2Component, pathMatch:'full'},
  {path:'my-orders',component: MyordersComponent},
  {path:'**', component: PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
