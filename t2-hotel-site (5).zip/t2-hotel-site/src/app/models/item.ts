export class Item {
    
    _id: string='';
    itemname: string='';
    itemdesc: string='';
    price: number=0;
    imagefilename:any
    quantity:number=0
    subtotal: any;
      
}
