import { Time } from "@angular/common";

export class Order{
  _id!: string;
  username!: string     
  emailid!: string         
  permanentaddress!: string
  deliveryaddress!: string
  phoneno1!: string      
  phoneno2!: string        
  ordereddate!: Date   
  deliverydate!: Date  
  subtotal!: number      
  gstpercentage!: number 
  gstamount!: number     
  deliverycharge!: number  
  grandtotal!: number     
  status!: string         
   itemname1!: string    
   itemdesc1!: string      
  price1!: number         
  quantity1!: number      
  imagefilename1!: string 
  itemname2!: string       
  itemdesc2!: string      
  price2!: number          
  quantity2!: number       
  imagefilename2!: string 
  orderedtime!: string    
  deliverytime!: string   
      


  //   _id: string='';
  //   itemname: string='';
  //   itemdesc: string='';
  //   price: number=0;
  //   imagefilename:any;
  //   quantity:number=0;
  //   username: string='';
  //   emailid: string='';
  //   permanentaddress: string='';
  //  deliveryaddress: string='';
  //   phoneno1: string='';
  //   phoneno2: string='';
  //    subtotal:number=0
  //   // amount: number=0;
  }
  