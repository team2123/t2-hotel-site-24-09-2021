import { Directive, Input } from '@angular/core';
import { AbstractControl,NG_VALIDATORS,Validator} from "@angular/forms";

@Directive({
  selector: '[appPassword]',
  providers: [{
    provide: NG_VALIDATORS,
    useExisting: PasswordDirective,
    multi: true
  }]
})
export class PasswordDirective implements Validator{
  @Input() appPassword: string=''

  validate(control: AbstractControl):{[key:string]: any} |null {
    const controlToCompare = control.parent?.get(this.appPassword);
    if(controlToCompare && controlToCompare.value !==control.value){
    return { 'notEqual': true}
    }
    return null;
    }
    }