import { PasswordDirective } from './password.directive';

describe('PasswordDirective', () => {
  it('should create an instance', () => {
    const directive = new PasswordDirective();
    expect(directive).toBeTruthy();
  });
});
