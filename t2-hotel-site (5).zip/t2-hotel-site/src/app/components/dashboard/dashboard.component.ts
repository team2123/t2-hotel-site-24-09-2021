import { Component, OnInit } from '@angular/core';
import { ItemService } from 'src/app/services/item.service';
import { Item } from "./../../models/item";
import { CommonserviceService } from "./../../services/commonservice.service";
import { Router } from '@angular/router';
import { OrderService } from "./../../services/order.service";
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  username: any
  emailid: any
  _id:any
  items: Item[] = [];
  total_no_of_records!: number;
  message = ''
  current_page: number = 1;
  quantity:number=0
  constructor(private itemService:ItemService, public commonService:CommonserviceService, private router: Router, private orderService:OrderService) { }

  ngOnInit(): void {
    this.getItemList()
    this.username = this.commonService.getusername()
  this.emailid = this.commonService.getemailid()
  this._id = this.commonService.get_id()
  }
  inc(item:any){
    this.quantity+=1
    item.quantity=this.quantity;
    item.subtotal=item.price * item.quantity;
  }
  dec(item:any){
    if(this.quantity!=1){
      this.quantity-=1
    }
    item.quantity=this.quantity
    item.subtotal=item.price * item.quantity;
  }

  getItemList() {
    this.itemService.getItems().subscribe(
      (result : any) => {
        this.items = result;
        this.total_no_of_records = this.items.length
      },
      (error) => {
        
        if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error
        }
      }
    );
  }
  
// addCart(item:any){
//   // if(this.quantity==0){
//   //   alert("success")
//   // }
//   this.orderService.createOrder(item).subscribe(
//     (result : any) => {
//       this.items = result;
//       this.total_no_of_records = this.items.length
      
//     },
//     (error) => {
     
//       if(error.status === 0 && error.statusText === 'Unknown Error') {
//         this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
//       } else if(error.status === 200 && error.statusText === 'OK') {
//         this.message = error.error.text// JWT Error
//       }
//     }
//   );
//   this.router.navigateByUrl('/cart')
// }
addToCart(item:Item){
  if(this.quantity==0)
  {
    alert('select quantity of item')
  }
  // let obj = {itemname1:item.itemname, price1:item.price, quantity1:item.quantity, _id:item._id,
  // itemdesc1:item.itemdesc,imagefilename1:item.imagefilename, subtotal:item.subtotal}
else{
  let cartItems=this.commonService.getCartItems();
  if(cartItems.itemname1==null)
  {
  cartItems.itemname1=item.itemname
    cartItems.price1=item.price
   cartItems.quantity1=item.quantity
  cartItems.itemdesc1=item.itemdesc
   cartItems.imagefilename1=item.imagefilename
  }
  else 
  {
    cartItems.itemname2=item.itemname
    cartItems.price2=item.price
    cartItems.quantity2=item.quantity
    cartItems.itemdesc2=item.itemdesc
    cartItems.imagefilename2=item.imagefilename
  }
  console.log('cartItems')
  console.log(cartItems)
  this.commonService.addAnItemToCart(cartItems)
}

}
}
