import { getMatScrollStrategyAlreadyAttachedError } from '@angular/cdk/overlay/scroll/scroll-strategy';
import { getAttrsForDirectiveMatching } from '@angular/compiler/src/render3/view/util';
import { Component, OnInit } from '@angular/core';
import { Order } from 'src/app/models/order';
import { CommonserviceService } from 'src/app/services/commonservice.service';
import { OrderService } from 'src/app/services/order.service';

@Component({
  selector: 'app-myorders',
  templateUrl: './myorders.component.html',
  styleUrls: ['./myorders.component.css']
})
export class MyordersComponent implements OnInit {

  order!: Order 
 
  //amount:any=300

  constructor(private orderService: OrderService, public commonService: CommonserviceService) { }
  ngOnInit(): void {
    // this.getAllOrders()
    this.getOrder();
  }
  getOrder()
  {
   this.orderService.getOrderById(this.commonService.order_id).subscribe((res)=>{
    this.order=res;
    })
  }


}
