import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderEdit2Component } from './order-edit2.component';

describe('OrderEdit2Component', () => {
  let component: OrderEdit2Component;
  let fixture: ComponentFixture<OrderEdit2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrderEdit2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderEdit2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
