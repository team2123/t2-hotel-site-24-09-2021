import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-edit2',
  templateUrl: './order-edit2.component.html',
  styleUrls: ['./order-edit2.component.css']
})
export class OrderEdit2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
