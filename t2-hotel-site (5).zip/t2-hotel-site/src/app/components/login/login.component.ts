import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonserviceService } from 'src/app/services/commonservice.service';
import { FoodserviceService } from "../../services/foodservice.service";
import { User } from "./../../models/user";
//import * as toastr from 'toastr';
//import '~ngx-toastr/toastr';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  emailid: any
  password: any

  error_message = ''

  constructor(private router: Router, private foodService: FoodserviceService, public commonService:CommonserviceService) { }
  ngOnInit(): void {
  }

  loginUser = () => {

    if(this.emailid=="admin@hotelsaravana.com"){ 
      var body = "emailid=" + this.emailid 
          + "&password=" + this.password;
     
  
      this.foodService.checkValidUser(body)
        .subscribe( (data: string) => {
          console.log('Login Result / JWT Token :')
          console.log(data) 
          if(data !== 'Login Failed') {// Login Successful, Got JWT Token
            //localStorage.setItem('loggedin', 'yes');
            // this.commonService.setJwtToken(data);// Store the Token in to CommonService
            // this.commonService.setLoginStatus(1);
  
  
            const result = JSON.parse(data)
            this.commonService.setLoginStatus(1);
            this.commonService.set_id(result['_id']);
            this.commonService.setusername(result['username']);
            this.commonService.setemailid(result['emailid']);
            this.commonService.setpassword(result['password']);
            this.commonService.setaddress(result['address']);
            this.commonService.setphoneno1(result['phoneno1']);
            this.commonService.setphoneno2(result['phoneno2']);
           
            this.commonService.setJwtToken(result['jwtToken']);
  
            localStorage.setItem('jwtToken', result['jwtToken']);  
            localStorage.setItem('username', result['username']); 
            localStorage.setItem('emailid', result['emailid']);
            localStorage.setItem('address', result['address']);
            localStorage.setItem('phoneno1', result['phoneno1']);
            localStorage.setItem('phoneno2', result['phoneno2']); 
           
  
            this.router.navigate(['admin-dashboard']);// User Dashboard
            
          } else {
            this.error_message = 'Login failed due to invalid Emailid or Password'// To Show Error Message in Login Page
          }
        
        });
      
      }else{
    //var body = "id=" + this.id 
    var body = "emailid=" + this.emailid 
        + "&password=" + this.password;
    // let result = {}

    this.foodService.checkValidUser(body)
      .subscribe( (data: string) => {
        console.log('Login Result / JWT Token :')
        console.log(data)
        if(data !== 'Login Failed') {// Login Successful, Got JWT Token
          //localStorage.setItem('loggedin', 'yes');
          // this.commonService.setJwtToken(data);// Store the Token in to CommonService
          // this.commonService.setLoginStatus(1);


          const result = JSON.parse(data)
          this.commonService.setLoginStatus(1);
          this.commonService.set_id(result['_id']);
          this.commonService.setusername(result['username']);
          this.commonService.setemailid(result['emailid']);
          this.commonService.setpassword(result['password']);
          this.commonService.setaddress(result['address']);
          this.commonService.setphoneno1(result['phoneno1']);
          this.commonService.setphoneno2(result['phoneno2']);
          // this.commonService.setmobileno(result['mobileno']);
          // this.commonService.setbirthdate(result['birthdate']);
          // this.commonService.setgender(result['gender']);
          // this.commonService.setphoto(result['photo']);
          this.commonService.setJwtToken(result['jwtToken']);

          localStorage.setItem('jwtToken', result['jwtToken']);  
          localStorage.setItem('username', result['username']); 
          localStorage.setItem('emailid', result['emailid']);
          localStorage.setItem('address', result['address']);
          localStorage.setItem('phoneno1', result['phoneno1']); 
          localStorage.setItem('phoneno2', result['phoneno2']);  
          // localStorage.setItem('mobileno', result['mobileno']); 
          // localStorage.setItem('birthdate', result['birthdate']); 
          // localStorage.setItem('gender', result['gender']); 
          // localStorage.setItem('photo', result['photo']); 

          this.router.navigate(['dashboard']);// User Dashboard
        } else {
        
         this.error_message = 'Login failed due to invalid Emailid or Password'

        }
      });}
  }

  clearMessage() {
    this.error_message = ''
  }
}


