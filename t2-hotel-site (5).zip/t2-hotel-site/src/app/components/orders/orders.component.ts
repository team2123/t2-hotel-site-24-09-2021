import { Component, OnInit } from '@angular/core';
import { OrderService } from 'src/app/services/order.service';
import { CommonserviceService } from "./../../services/commonservice.service";
import { Router } from '@angular/router';
import { Order } from 'src/app/models/order';
import { Time } from '@angular/common';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {
  username: any
  emailid: any
  _id:any
  address: any
  phoneno1:any
  phoneno2:any
  // minDate = new Date();
  // maxDate = new Date(2021,8,22);
  deliveryaddress: any
  order!:Order
  orderDate=new Date();
  deliveryDate=new Date();
  orderTime!:string
  deliveryTime!:string
  
  
 // address1: any

  constructor( public commonService:CommonserviceService, private orderService:OrderService, private router: Router) { }

  ngOnInit(): void {
  this.username = this.commonService.getusername()
  this.emailid = this.commonService.getemailid()
  this._id = this.commonService.get_id()
  this.address = this.commonService.getaddress()
  this.phoneno1 = this.commonService.getphoneno1()
  this.phoneno2 = this.commonService.getphoneno2()
 


  // this.address1 = this.address
  }
placeOrder()
{
  // var obj= { username:this.username,
  //   emailid:this.emailid,
  //   _id:this._id,
  //   permanentaddress: this.address,
  //   phoneno1:this.phoneno1,
  //   phoneno2:this.phoneno2,
  //   deliveryaddress: this.deliveryaddress,
  //   itemname:' ',
  //   quantity:' ',
  //   price:' ',
  //   itemdesc:' ',
  //   subtotal:' ',
  //  // permanentaddress:' '
  // }
 
  let obj=this.commonService.getCartItems()
  obj.deliveryaddress=this.deliveryaddress;
  obj.ordereddate=this.orderDate;
  obj.orderedtime=this.orderTime;
  obj.deliverytime=this.deliveryTime;
  obj.deliverydate=this.deliveryDate;
 
    this.orderService.createOrder(obj).subscribe((res:any)=>{
      
      console.log("This is the created order",res);
      this.commonService.order_id=res._id;
      

    })
    this.router.navigate(['order-success']);
}
 

}
