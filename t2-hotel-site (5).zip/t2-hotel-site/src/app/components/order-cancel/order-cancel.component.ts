import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-cancel',
  templateUrl: './order-cancel.component.html',
  styleUrls: ['./order-cancel.component.css']
})
export class OrderCancelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
