import { Component, OnInit } from '@angular/core';
import { CommonserviceService } from 'src/app/services/commonservice.service';
import { Order } from "./../../models/order";
import { OrderService } from "./../../services/order.service";


@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  order!: Order 
  total_no_of_records:any
  message = ''
  quantity:any
  subtotal:any=0
  grandtotal:number=0;
  deliverycharge:any="";
  gst=0;
  //amount:any=300

  constructor(private orderService: OrderService, public commonService: CommonserviceService) { }
  ngOnInit(): void {
    // this.getAllOrders()
    this.order = this.commonService.getCartItems()
    this.GST();
    this.order.gstamount=this.GST();
    this.order.subtotal=this.getSubTotal();
    this.order.deliverycharge=this.delcharge();
    this.order.gstpercentage=this.commonService.gstpercentage;
    this.order.grandtotal=this.GrandTotal();
    this.order.status=this.commonService.status;
    this.commonService.addAnItemToCart(this.order);
  }
  // emptyCart(){
  //   this.orders=this.commonService.clearCart()
  // }
  
 
  
  getAllOrders(){
    // this.commonService.getCartItems().subscribe(
    //   (result : any) => {
    //     this.orders = result;
    //     this.total_no_of_records = this.orders.length
    //     this.getSubTotal()
    //   })
    }
    //   (error) => {
       
    //     if(error.status === 0 && error.statusText === 'Unknown Error') {
    //       this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
    //     } else if(error.status === 200 && error.statusText === 'OK') {
    //       this.message = error.error.text// JWT Error
    //     }
    //   }
    // );
  
  // delete1Order(order:Order) {
  //   if(window.confirm(`Are you sure to delete this ${order.itemname1} Item?`)) {
  //     // this.orderService.deleteItem(order._id)
  //     //   .subscribe( data => {
  //     //     this.orders = this.orders.filter(u => u !== order);
  //     //   })
  //   }
  // }
 
  getSubTotal(){
    // let subtotal = 0;
    if(this.order.itemname2!=null)
    {
      this.subtotal=this.order.price1*this.order.quantity1+this.order.price2*this.order.quantity2
  }
  else{
    this.subtotal=this.order.price1*this.order.quantity1;
  }
      console.log(this.subtotal)

    
    // this.grandtotal+=this.subtotal
     return this.subtotal;
}
delcharge = () => {
  if(this.subtotal<="500" ){
    // this.grandtotal+=50
  return this.deliverycharge=50;
  }
  else {
    return this.deliverycharge=0;
  }
}
GST=()=>{
  this.gst = this.commonService.GSTpercentage() * this.getSubTotal();
  // this.grandtotal+=gstamount
  return this.gst
}
GrandTotal=()=>{
this.grandtotal=this.subtotal+this.deliverycharge+this.gst;
return this.grandtotal;
}

}
