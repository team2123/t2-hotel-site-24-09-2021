import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { HttpClient } from '@angular/common/http';



@Component({
  selector: 'app-order-address',
  templateUrl: './order-address.component.html',
  styleUrls: ['./order-address.component.css']
})
export class OrderAddressComponent implements OnInit {
  address:any[] = [
    {name:'Kartik Rana', contact:'7082187177',address:'VPO Arainpura Karnal',pincode:'132114'},
    {name:'Harsh Rana', contact:'70821xxxxx',address:'Karnal Haryana',pincode:'134001'},
    {name:'Rajat ', contact:'78291xxxxx',address:'Chandigarh,India',pincode:'124901'},
    {name:'Ansh', contact:'70824xxxxx',address:'Bangalore,India',pincode:'560097'},
     ]

  id:any
  user_name:string = ''
  email_id:string = ''
  pass_word:string = ''
  message = ''
  phone_number:any=''
  pincode:any=''
  addrs:string=''


  constructor(private router: Router) { }

  ngOnInit(): void {

  }

  // addAddress(){
  //   let inputEl = this.elementRef.nativeElement.querySelector('#file1');
  //   var formData = new FormData();
  //   formData.append("itemname", this.itemname);
  //   formData.append("itemdesc", this.itemdesc);
  //   formData.append("price",    this.price);
  //   formData.append('file1', inputEl.files.item(0) );
  
  //   this.itemService.createItem(formData).subscribe(
  //     result => {
  //       this.router.navigate(['item-list']);
  //     },
  //     error => {
  //       //this.message = error.error
  //       alert('Error while Adding an Item!')
  //     });
  // }

  // clearMessage() {
  //   this.message = ''
  // }

  // }

  // addAddress = () => {
  //   var body = "user_name=" + this.user_name 
  //       + "&email_id=" + this.email_id 
  //       + "&pass_word=" + this.pass_word;

  //   this.OrderDeliveryService.createItem(body)
  //     .subscribe( (data :any) => {
  //       this.router.navigate(['userlist']);
  //     },
  //     (error) => {
  //       this.message = error.error
  //     });

  // }

  // clearMessage() {
  //   this.message = ''
  // }
}

