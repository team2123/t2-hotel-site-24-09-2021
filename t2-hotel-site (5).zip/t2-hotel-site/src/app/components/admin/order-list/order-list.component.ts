import { Component, OnInit } from '@angular/core';
import { OrderService } from 'src/app/services/order.service';
import { Order } from "./../../../models/order";

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.css']
})
export class OrderListComponent implements OnInit {

  constructor(private orderService: OrderService) { }
  orders: Order[] = [];
  total_no_of_records!: number;
  current_page: number = 1;// Pagination setting - Current Page defaulted to First Page
  no_of_records_per_page: number = 5;// Pagination setting - No of records per page set to 5
  message = ''

  ngOnInit(): void {
    this.getOrderList()
  }

  getOrderList() {
    this.orderService.getOrders().subscribe(
      (result : any) => {
        this.orders = result;
        this.total_no_of_records = this.orders.length
      },
      (error) => {
       
        if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error
        }
      }
    );
  }

  setNegative() {
    this.total_no_of_records = -1
  }

  clearMessage() {
    this.message = ''
  }

}
