import { Component, OnInit, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {first} from "rxjs/operators";
import { OrderService } from "./../../../services/order.service";


@Component({
  selector: 'app-order-edit',
  templateUrl: './order-edit.component.html',
  styleUrls: ['./order-edit.component.css']
})
export class OrderEditComponent implements OnInit {
  _id:any
  itemname1:any
  itemdesc1:any
  price1:any
  imagefilename1:any
  itemname2:any
  itemdesc2:any
  price2:any
  imagefilename2:any
  status:any
  uploadedFiles:Array <File>=[];

  constructor(private route: ActivatedRoute, private orderService: OrderService, private router: Router, private elementRef:ElementRef) { }
  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this._id = params['_id'];
      console.log(this._id);
    })
    this.orderService.getOrderById(this._id)
      .subscribe( data1 => {
        console.log(data1)
        // this.itemname1 = data1.itemname1;
        // this.itemdesc1 = data1.itemdesc1;
        // this.price1    = data1.price1;
        // this.itemname2 = data1.itemname2;
        // this.itemdesc2 = data1.itemdesc2;
        // this.price2    = data1.price2;
        this.status=data1.status
        //this.imagefilename    = data1.imagefilename;
      },
      error => {
        alert(error);
      });
  }
  // fileChange(element:any) {
  //   this.uploadedFiles = element.target.files;
  // }

  editOrder() {
    // var body = "_id=" + this._id 
    //     + "&itemname=" + this.itemname 
    //     + "&itemdesc=" + this.itemdesc 
    //     + "&price=" + this.price;
       // + "&imagefilename=" + this.imagefilename;
    // console.log(body)
    // let inputEl = this.elementRef.nativeElement.querySelector('#file1');
    // var formData = new FormData();
    // formData.append("itemname", this.itemname);
    // formData.append("itemdesc", this.itemdesc);
    // formData.append("price",    this.price);
    // formData.append('file1', inputEl.files.item(0) );
    var body = "_id=" + this._id 
        + "&status=" + this.status;

    this.orderService.updateOrder(body, this._id)
      .pipe(first())
      .subscribe(
        data => {
          this.router.navigate(['order-list']);
          console.log("updateOrdeerStatus response",data,"status",this.status,"body",body)
        },
        error => {
          alert(error);
        });
  }
}