import { Component, OnInit } from '@angular/core';
import { User } from "./../../../models/user";
import { FoodserviceService } from "./../../../services/foodservice.service";
@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  users: User[] = [];
  total_no_of_records:any;
  current_page: number = 1;// Pagination setting - Current Page defaulted to First Page
  no_of_records_per_page: number = 5;// Pagination setting - No of records per page set to 5
  message = ''

  constructor(private foodService:FoodserviceService) {}

  ngOnInit(): void {
    this.getUserList()
  }

  getUserList() {
    this.foodService.getUsers().subscribe(
      (result:any) => {
        this.users = result;
        this.total_no_of_records = this.users.length
      },
      (error: { status: number; statusText: string; error: { text: string; }; }) => {
        // console.log('error')
        // console.log(error)
        // console.log(error.name)// HttpErrorResponse, if Backend is not running
        //this.message = error.name
        if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error / Any other error
        }
      }
    );
  }

  delete1User(user: User) {
    if(window.confirm(`Are you sure to delete the record with Email Id = ${user.emailid}?`)) {
      this.foodService.deleteUser(user._id)
        .subscribe( (data: any) => {
          this.users = this.users.filter(u => u !== user);
        })
    }
  }

  setNegative() {
    this.total_no_of_records = -1
  }

  clearMessage() {
    this.message = ''
  }

}
