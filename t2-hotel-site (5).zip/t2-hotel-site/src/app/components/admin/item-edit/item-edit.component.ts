import { Component, OnInit, ElementRef} from '@angular/core';
import { ItemService } from './../../../services/item.service';
import { ActivatedRoute, Router } from '@angular/router';
import {first} from "rxjs/operators";

@Component({
  selector: 'app-item-edit',
  templateUrl: './item-edit.component.html',
  styleUrls: ['./item-edit.component.css']
})
export class ItemEditComponent implements OnInit {
  _id:any
  itemname:any
  itemdesc:any
  price:any
  imagefilename:any
  uploadedFiles:Array <File>=[];

  constructor(private route: ActivatedRoute, private itemService: ItemService, private router: Router, private elementRef:ElementRef) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this._id = params['_id'];
      console.log(this._id);
    })
    this.itemService.getItemById(this._id)
      .subscribe( data1 => {
        console.log(data1)
        this.itemname = data1.itemname;
        this.itemdesc = data1.itemdesc;
        this.price    = data1.price;
        //this.imagefilename    = data1.imagefilename;
      },
      error => {
        alert(error);
      });
  }
  fileChange(element:any) {
    this.uploadedFiles = element.target.files;
  }

  editItem() {
    // var body = "_id=" + this._id 
    //     + "&itemname=" + this.itemname 
    //     + "&itemdesc=" + this.itemdesc 
    //     + "&price=" + this.price;
       // + "&imagefilename=" + this.imagefilename;
    // console.log(body)
    let inputEl = this.elementRef.nativeElement.querySelector('#file1');
    var formData = new FormData();
    formData.append("itemname", this.itemname);
    formData.append("itemdesc", this.itemdesc);
    formData.append("price",    this.price);
    formData.append('file1', inputEl.files.item(0) );

    this.itemService.updateItem(formData, this._id)
      .pipe(first())
      .subscribe(
        data => {
          this.router.navigate(['item-list']);
        },
        error => {
          alert(error);
        });
  }
}

