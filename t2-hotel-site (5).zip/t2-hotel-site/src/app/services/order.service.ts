import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CommonserviceService } from './commonservice.service';
import { Order } from "./../models/order";


@Injectable({
  providedIn: 'root'
})
export class OrderService {
  api_url:string = "http://localhost:9000/v1/order/"
  jwtToken: any;
  headers:any

  constructor(private http:HttpClient, private commonService:CommonserviceService) { }

  getItem() {
    return this.http.get(this.api_url);
  }
  getOrders() {
    //return this.http.get(this.api_url);
    
    this.jwtToken = this.commonService.getJwtToken()
    this.headers  = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded', "Authorization": this.jwtToken});
    //console.log('ItemService getItems() : ' + this.jwtToken)
    return this.http.get(this.api_url, {headers: this.headers});
  }
  createOrder(formData: any) {
    //let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    
    this.jwtToken = this.commonService.getJwtToken()
    this.headers  = new HttpHeaders({"Authorization": this.jwtToken});
    return this.http.post(this.api_url, formData, {headers:this.headers, responseType:'json'});
    // return this.http.post(this.api_url, formData);
  }
  deleteItem(orderid: string) {
    //return this.http.get(this.api_url + '/delete/' + itemid);//Interim
    // return this.http.delete(this.api_url + '/' + itemid);//Actual
    this.jwtToken = this.commonService.getJwtToken()
    this.headers  = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded', "Authorization": this.jwtToken});
    return this.http.delete(this.api_url + orderid, {headers: this.headers});//Actual
  }
  getOrderById(orderid: string){
    this.jwtToken = this.commonService.getJwtToken()
    this.headers  = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded', "Authorization": this.jwtToken});
    return this.http.get<Order>(this.api_url + orderid, {headers: this.headers});

  }

  updateOrder(body: string, orderid: string){
    this.jwtToken = this.commonService.getJwtToken()
    this.headers  = new HttpHeaders({"Authorization": this.jwtToken,'Content-Type': 'application/x-www-form-urlencoded'});
    return this.http.put(this.api_url + orderid, body, {headers: this.headers, responseType:'text'});
  }


}
