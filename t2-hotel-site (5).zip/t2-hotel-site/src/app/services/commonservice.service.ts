import { Injectable } from '@angular/core';
import { Order } from "./../models/order";

@Injectable({
  providedIn: 'root'
})
export class CommonserviceService {
  public loginStatus = 0;// 0 = not logged in, 1 = logged in
  //public adminloginStatus=0;
  public jwtToken = '';// JWT - Json Web Token
  public _id = '';
  public username = '';
  public emailid = '';
  public password = '';
  public address = '';
  public phoneno1='';
  public phoneno2='';
  public deliveryaddress=''
  public gstpercentage:number=0.10;
  public status='ordered';
  public order_id='';
  // public mobileno = 0;
  cartItems!:Order;

  constructor() {
    this.cartItems=new Order();
    
   }

  resetAll() {
    this.loginStatus = 0;
   // this.adminloginStatus=0;
    this.jwtToken = '';
    this._id = '';
    this.username = '';
    this.emailid = '';
    this.password = '';
    this.address = '';
    this.phoneno1='';
    this.phoneno2='';
    this.gstpercentage=0.10;
    // this.mobileno = 0;
  
  }
  setLoginStatus(status : number) {
    this.loginStatus = status;
  }
  getLoginStatus() {
    return this.loginStatus
  }
 

  addAnItemToCart(cartItems:Order) {
    
    this.cartItems.username=this.username;
    this.cartItems.emailid=this.emailid;
    this.cartItems.permanentaddress=this.address;
     this.cartItems.deliveryaddress=this.deliveryaddress;
     this.cartItems.status=this.status
    this.cartItems.phoneno1=this.phoneno1;
    this.cartItems.phoneno2=this.phoneno2;
  this.cartItems=cartItems
  
    //alert('Added 1 item in to Cart')
    console.log("this.cartItems")
    console.log(this.cartItems)
    
  }

  getCartItems() {
    return this.cartItems;
  }

  clearCart() {
  
    
      this.cartItems.itemname1=''
      this.cartItems.price1=0
      this.cartItems.quantity1=0
      this.cartItems.itemdesc1=''
      this.cartItems.imagefilename1=''
    
 
    
      this.cartItems.itemname2=''
      this.cartItems.price2=0
      this.cartItems.quantity2=0
      this.cartItems.itemdesc2=''
      this.cartItems.imagefilename2=''
    
  
  }
  GSTpercentage(){
    return this.gstpercentage;
  }


 
  setJwtToken(token : string) {
    this.jwtToken = token;
  }
  getJwtToken() {
    return this.jwtToken;
  }
  
  set_id(x : string) {
    this._id = x;
  }
  get_id() {
    return this._id;
  }

  setusername(x : string) {
    this.username = x;
  }
  getusername() {
    return this.username;
  }

  setemailid(x : string) {
    this.emailid = x;
  }
  getemailid() {
    return this.emailid;
  }
 
  setpassword(x : string) {
    this.password = x;
  }
  getpassword() {
    return this.password;
  }
  setaddress(x : string) {
    this.address = x;
  }
  getaddress() {
    return this.address;
    
  }
  setphoneno1(x : string) {
    this.phoneno1 = x;
  }
  getphoneno1() {
    return this.phoneno1;
  }
  setphoneno2(x : string) {
    this.phoneno2 = x;
  }
  getphoneno2() {
    return this.phoneno2;
  }
 
}

