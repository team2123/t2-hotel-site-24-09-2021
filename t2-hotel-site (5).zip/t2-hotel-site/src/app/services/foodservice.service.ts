import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import { User } from "./../models/user";


@Injectable({
  providedIn: 'root'
})
export class FoodserviceService {
  apiUrl: string= "http://localhost:9000/v1/user/"

  constructor(private http: HttpClient) { }

  getUsers() {
    return this.http.get(this.apiUrl);
  }
  createUser(body: string) {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    return this.http.post(this.apiUrl, body, {headers: headers, responseType:'text'});
  }

  checkValidUser(body: string) {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    return this.http.post(this.apiUrl + 'login', body, {headers: headers, responseType:'text'});
  }
  deleteUser(userid: string) {
    //return this.http.get(this.api_url + '/delete/' + userid);//Interim
    // return this.http.delete(this.api_url + '/' + userid);//Actual
    return this.http.delete(this.apiUrl + userid);//Actual
  }
  getUserById(userid: string) {
    // return this.http.get<UserClass>(this.api_url + '/' + userid);
    return this.http.get<User>(this.apiUrl + userid);
  }

  updateUser(body: string, userid: string) {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    // return this.http.put(this.api_url + '/' + userid, body, {headers: headers, responseType:'text'});
    return this.http.put(this.apiUrl + userid, body, {headers: headers, responseType:'text'});
  }



}
